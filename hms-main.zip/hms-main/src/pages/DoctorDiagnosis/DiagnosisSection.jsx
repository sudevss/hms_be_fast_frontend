import { useMemo, useState, useRef } from "react";
import {
  Box,
  IconButton,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
} from "@mui/material";

import StyledButton from "@components/StyledButton";
import { MaterialReactTable } from "material-react-table";
import { dayjs } from "@/utils/dateUtils";

import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";

const DiagnosisSection = ({ patientId, patientName, tokenNumber, appointmentDate }) => {
  const [data, setData] = useState([]);
  const [editingRowId, setEditingRowId] = useState(null);

  // Delete confirmation state
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [rowToDelete, setRowToDelete] = useState(null);

  const printRef = useRef();

  const columns = useMemo(
    () => [
      {
        accessorKey: "diagnosis_date",
        header: "Diagnosis Date",
        muiEditTextFieldProps: {
          type: "date",
          slotProps: {
            input: {
              max: dayjs().format("YYYY-MM-DD"),
            },
          },
        },
        Cell: ({ cell }) => dayjs(cell.getValue()).format("YYYY-MM-DD"),
      },
      {
        accessorKey: "chief_complaint",
        header: "Chief Complaint",
        muiEditTextFieldProps: { multiline: true, rows: 1 },
      },
      {
        accessorKey: "assessment_notes",
        header: "Assessment Notes",
        muiEditTextFieldProps: { multiline: true, rows: 1 },
      },
      {
        accessorKey: "treatment_plan",
        header: "Treatment Plan",
        muiEditTextFieldProps: { multiline: true, rows: 1 },
      },
      {
        accessorKey: "recomm_tests",
        header: "Recommended Tests",
        muiEditTextFieldProps: { multiline: true, rows: 1 },
      },
    ],
    []
  );

  const handleAddRow = () => {
    const newRow = {
      id: Date.now(),
      diagnosis_date: dayjs().format("YYYY-MM-DD"),
      chief_complaint: "",
      assessment_notes: "",
      treatment_plan: "",
      recomm_tests: "",
    };
    setData((prev) => [newRow, ...prev]);
  };

  const handlePrint = () => {
    const printContent = printRef.current.innerHTML;
    const win = window.open("", "_blank", "width=900,height=650");
    win.document.write(`
      <html>
        <head>
          <title>Diagnosis Print</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            .center-heading {
              text-align: center;
              color: #115E59;
              font-size: 1.5rem;
              font-weight: 700;
              margin-bottom: 10px;
            }
            .patient-header {
              background-color: transparent;
              color: #000;
              padding: 0;
              margin-bottom: 20px;
              font-size: 1.1rem;
              line-height: 1.6;
            }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            table th {
              background-color: #115E59;
              color: white;
              padding: 8px;
              border: 1px solid #ccc;
              text-align: left;
            }
            table td { padding: 8px; border: 1px solid #ccc; }
          </style>
        </head>
        <body>
          <div class="center-heading">Apple Medical Center</div>
          <div class="patient-header">
            <strong>P_id:</strong> ${patientId || "-"} <br />
            <strong>Name:</strong> ${patientName || "-"} <br />
            <strong>Token Number:</strong> ${tokenNumber || "-"} <br />
            <strong>Appointment Date:</strong> ${appointmentDate || "-"}
          </div>
          ${printContent}
        </body>
      </html>
    `);
    win.document.close();
    win.print();
  };

  const handleSaveRow = ({ row, values }) => {
    setData((prev) =>
      prev.map((r) => (r.id === row.original.id ? { ...r, ...values } : r))
    );
    setEditingRowId(null);
  };

  const handleDeleteRow = ({ row }) => {
    setData((prev) => prev.filter((r) => r.id !== row.original.id));
  };

  return (
    <Box sx={{ borderRadius: 2, border: "1px solid #e5e7eb", p: 2, mt: 3 }}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          mb: 2,
        }}
      >
        <Box sx={{ fontWeight: 700, fontSize: "1rem" }}>Diagnosis</Box>
        <Box sx={{ display: "flex", gap: 1 }}>
          <StyledButton variant="outlined" onClick={handlePrint}>
            Print
          </StyledButton>
          <StyledButton variant="contained" onClick={handleAddRow}>
            Add
          </StyledButton>
        </Box>
      </Box>

      <MaterialReactTable
        columns={columns}
        data={data}
        enableEditing
        editDisplayMode="row"
        onEditingRowSave={handleSaveRow}
        onEditingRowCancel={() => setEditingRowId(null)}
        enableSorting
        enableColumnFilters={false}
        enableGlobalFilter={false}
        enableColumnActions={false}
        enableTopToolbar={false}
        enableBottomToolbar={false}
        enableFullScreenToggle={false}
        enableDensityToggle={false}
        enableHiding={false}
        renderRowActions={({ row, table }) => {
          const isEditing = editingRowId === row.original.id;
          return (
            <Box sx={{ display: "flex", gap: 1 }}>
              {isEditing ? (
                <>
                  <Tooltip title="Save" arrow>
                    <IconButton
                      size="small"
                      onClick={() => {
                        table.setEditingRow(null);
                        setEditingRowId(null);
                      }}
                    >
                      <SaveIcon sx={{ color: "#115E59", fontSize: "1.25rem" }} />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Cancel" arrow>
                    <IconButton
                      size="small"
                      onClick={() => {
                        table.setEditingRow(null);
                        setEditingRowId(null);
                      }}
                    >
                      <CancelIcon sx={{ color: "#dc2626", fontSize: "1.25rem" }} />
                    </IconButton>
                  </Tooltip>
                </>
              ) : (
                <>
                  <Tooltip title="Edit" arrow>
                    <IconButton
                      size="small"
                      onClick={() => {
                        setEditingRowId(row.original.id);
                        table.setEditingRow(row);
                      }}
                    >
                      <EditOutlinedIcon
                        sx={{ color: "#115E59", fontSize: "1.25rem" }}
                      />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Delete" arrow>
                    <IconButton
                      color="error"
                      size="small"
                      onClick={() => {
                        setRowToDelete(row);
                        setDeleteConfirmOpen(true);
                      }}
                    >
                      <DeleteForeverIcon sx={{ fontSize: "1.25rem" }} />
                    </IconButton>
                  </Tooltip>
                </>
              )}
            </Box>
          );
        }}
      />

      {/* Hidden print table */}
      <div ref={printRef} style={{ display: "none" }}>
        <table>
          <thead>
            <tr>
              <th>Diagnosis Date</th>
              <th>Chief Complaint</th>
              <th>Assessment Notes</th>
              <th>Treatment Plan</th>
              <th>Recommended Tests</th>
            </tr>
          </thead>
          <tbody>
            {data.length === 0 ? (
              <tr>
                <td colSpan={5} style={{ textAlign: "center" }}>
                  No diagnosis entries added
                </td>
              </tr>
            ) : (
              data.map((row) => (
                <tr key={row.id}>
                  <td>{row.diagnosis_date}</td>
                  <td>{row.chief_complaint}</td>
                  <td>{row.assessment_notes}</td>
                  <td>{row.treatment_plan}</td>
                  <td>{row.recomm_tests}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Delete confirmation dialog */}
      <Dialog
        open={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
      >
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          Are you sure you want to delete this diagnosis entry?
        </DialogContent>
        <DialogActions>
          <StyledButton
            variant="outlined"
            onClick={() => setDeleteConfirmOpen(false)}
          >
            Cancel
          </StyledButton>
          <StyledButton
            variant="contained"
            color="error"
            onClick={() => {
              if (rowToDelete) handleDeleteRow({ row: rowToDelete });
              setDeleteConfirmOpen(false);
              setRowToDelete(null);
            }}
          >
            Delete
          </StyledButton>
        </DialogActions>
      </Dialog>
    </Box>
    
  );
};

export default DiagnosisSection;

