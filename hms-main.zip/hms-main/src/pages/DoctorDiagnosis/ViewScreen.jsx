import {
  AppBar,
  Box,
  Dialog,
  IconButton,
  Toolbar,
  Typography,
  TextField,
  Button,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import { useState, useEffect } from "react";
import CloseIcon from "@mui/icons-material/Close";
import PrintIcon from "@mui/icons-material/Print";
import DiagnosisSection from "./DiagnosisSection";
import PrescriptionSection from "./PrescriptionSection";
import LabTestSection from "./LabTestSection";
import ProcedureSection from "./ProcedureSection";
import DiagnosisRightSidebar from "./DiagnosisRightSidebar";
import { dayjs } from "@/utils/dateUtils";

const labelSx = {
  color: "#6b7280",
  fontWeight: 600,
  textTransform: "uppercase",
  fontSize: "1.0rem",
};
const valueSx = { color: "#111827", fontWeight: 600, fontSize: "1.0rem" };

const Field = ({ label, value }) => (
  <Box>
    <Typography variant="caption" sx={labelSx}>
      {label}
    </Typography>
    <Box sx={{ height: 6 }} />
    <Typography variant="body1" sx={valueSx}>
      {value ?? "-"}
    </Typography>
  </Box>
);

const ViewScreen = ({ open, onClose, appointment }) => {
  const [currentAppointment, setCurrentAppointment] = useState(appointment);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [chiefComplaint, setChiefComplaint] = useState("");
  const [diagnosis, setDiagnosis] = useState(null);
  const [prescriptions, setPrescriptions] = useState([]);
  const [labTests, setLabTests] = useState([]);
  const [procedures, setProcedures] = useState([]);

  // Submission Confirmation Dialog
  const [confirmOpen, setConfirmOpen] = useState(false);

  useEffect(() => {
    setCurrentAppointment(appointment);
    const sampleDiagnosis = {
      vital_bp: "120/80 mmHg",
      vital_hr: 78,
      vital_temp: "98.6 °F",
      height: "170 cm",
      weight: "65 kg",
      vital_spo2: "98%",
      chief_complaint: "",
    };
    setDiagnosis(sampleDiagnosis);
    setChiefComplaint("");
  }, [appointment]);

  const tokenNumber =
    currentAppointment?.token ??
    currentAppointment?.appointment_id ??
    "-";

  const patientName =
    currentAppointment?.patient_name ??
    currentAppointment?.name ??
    currentAppointment?.firstname ??
    "-";

  const visitDateRaw =
    currentAppointment?.date ??
    currentAppointment?.appointment_date;

  const visitDate = visitDateRaw
    ? dayjs(visitDateRaw).format("DD-MM-YYYY")
    : "-";

  // Open confirmation before actual submission
  const handleSubmitClick = () => setConfirmOpen(true);

  const handleConfirmSubmit = () => {
    setConfirmOpen(false);

    const dataToSubmit = {
      appointmentId: currentAppointment?.appointment_id,
      patientId: currentAppointment?.patient_id,
      chiefComplaint,
      diagnosis,
      prescriptions,
      labTests,
      procedures,
    };
    console.log("Submitting data:", dataToSubmit);
    // Add your API call or submission logic here
  };

  const handleCancelSubmit = () => setConfirmOpen(false);

  return (
    <>
      <Dialog fullScreen open={open} onClose={onClose}>
        {/* AppBar */}
        <AppBar
          sx={{
            position: "fixed",
            bgcolor: "#115E59",
            zIndex: (theme) => theme.zIndex.drawer + 2,
            '@media print': { display: 'none' },
          }}
        >
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={onClose}>
              <CloseIcon />
            </IconButton>
            <Typography sx={{ ml: 2, flex: 1 }} variant="h6">
              Doctor Diagnosis
            </Typography>
            <IconButton edge="end" color="inherit" onClick={() => window.print()}>
              <PrintIcon />
            </IconButton>
          </Toolbar>
        </AppBar>

        <Toolbar />

        <Box
          sx={{
            width: "100%",
            p: 0,
            display: "flex",
            gap: 2,
            '@media print': { display: 'block', gap: 0 },
            '& button, & .MuiIconButton-root': { '@media print': { display: 'none !important' } },
          }}
        >
          {/* LEFT CONTENT AREA */}
          <Box
            sx={{
              flexGrow: 1,
              p: 3,
              pt: 0,
              overflowY: "auto",
              height: "100vh",
              '@media print': { height: 'auto', overflowY: 'visible', p: 2 }
            }}
          >
            {/* Patient Details */}
            <Box
              sx={{
                position: "sticky",
                top: 64,
                zIndex: (theme) => theme.zIndex.appBar - 1,
                bgcolor: "#ffffff",
                p: 2,
                borderBottom: "1px solid #e5e7eb",
                '@media print': { position: 'static', top: 'auto' }
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: { xs: "column", md: "row" },
                  alignItems: "center",
                  gap: 2,
                  width: "100%",
                }}
              >
                <Box sx={{ flex: "1 1 33%", textAlign: "left" }}>
                  <Field label="Token Number" value={tokenNumber} />
                </Box>
                <Box sx={{ flex: "1 1 34%", textAlign: "center" }}>
                  <Field label="Patient Name" value={patientName} />
                </Box>
                <Box sx={{ flex: "1 1 33%", textAlign: "right" }}>
                  <Field label="Date of Visit" value={visitDate} />
                </Box>
              </Box>
            </Box>

            {/* Vitals */}
            <Box sx={{ borderRadius: 2, border: "1px solid #e5e7eb", p: 2, mt: 3 }}>
              <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 2 }}>
                Vitals
              </Typography>
              <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
                <Box sx={{ flex: "1 1 0", textAlign: "center" }}>
                  <Field label="Blood Pressure" value={diagnosis?.vital_bp} />
                </Box>
                <Box sx={{ flex: "1 1 0", textAlign: "center" }}>
                  <Field label="Heart Rate" value={diagnosis?.vital_hr} />
                </Box>
                <Box sx={{ flex: "1 1 0", textAlign: "center" }}>
                  <Field label="Temperature" value={diagnosis?.vital_temp} />
                </Box>
                <Box sx={{ flex: "1 1 0", textAlign: "center" }}>
                  <Field label="Height" value={diagnosis?.height} />
                </Box>
                <Box sx={{ flex: "1 1 0", textAlign: "center" }}>
                  <Field label="Weight" value={diagnosis?.weight} />
                </Box>
                <Box sx={{ flex: "1 1 0", textAlign: "center" }}>
                  <Field label="SPO2" value={diagnosis?.vital_spo2} />
                </Box>
              </Box>
            </Box>

            {/* Chief Complaint */}
            <Box sx={{ borderRadius: 2, border: "1px solid #e5e7eb", p: 2, mt: 3 }}>
              <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 2 }}>
                Chief Complaints
              </Typography>
              <TextField
                fullWidth
                multiline
                minRows={3}
                value={chiefComplaint}
                onChange={(e) => setChiefComplaint(e.target.value)}
                placeholder="Enter chief complaints"
              />
            </Box>

            {/* Sections */}
            <DiagnosisSection
              patientId={currentAppointment?.patient_id}
              patientName={patientName}
              tokenNumber={tokenNumber}
              appointmentDate={visitDate}
            />
            <PrescriptionSection
              patientId={currentAppointment?.patient_id}
              patientName={patientName}
              tokenNumber={tokenNumber}
              appointmentDate={visitDate}
            />
            <LabTestSection
              patientId={currentAppointment?.patient_id}
              patientName={patientName}
              tokenNumber={tokenNumber}
              appointmentDate={visitDate}
            />
            <Box sx={{ '@media print': { pageBreakBefore: 'always' } }}>
              <ProcedureSection
                patientId={currentAppointment?.patient_id}
                patientName={patientName}
                tokenNumber={tokenNumber}
                appointmentDate={visitDate}
              />
            </Box>

            {/* Submit Button */}
            <Box sx={{ mt: 3, display: "flex", justifyContent: "center" }}>
              <Button
                variant="contained"
                color="primary"
                onClick={handleSubmitClick}
              >
                Submit
              </Button>
            </Box>
          </Box>

          {/* RIGHT SIDEBAR */}
          <Box sx={{ '@media print': { display: 'none' } }}>
            <DiagnosisRightSidebar
              isOpen={isSidebarOpen}
              onToggle={() => setIsSidebarOpen((prev) => !prev)}
              patientId={currentAppointment?.patient_id}
            />
          </Box>
        </Box>
      </Dialog>

      {/* Submission Confirmation Dialog */}
      <Dialog open={confirmOpen} onClose={handleCancelSubmit}>
        <DialogTitle>Confirm Submission</DialogTitle>
        <DialogContent>
          Are you sure you want to submit this diagnosis and associated data?
        </DialogContent>
        <DialogActions>
          <Button variant="outlined" onClick={handleCancelSubmit}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" onClick={handleConfirmSubmit}>
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default ViewScreen;
